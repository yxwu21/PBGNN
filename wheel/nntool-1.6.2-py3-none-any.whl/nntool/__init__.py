from .version import VERSION, VERSION_SHORT

__all__ = [
    "VERSION",
    "VERSION_SHORT",
]
__version__ = VERSION
